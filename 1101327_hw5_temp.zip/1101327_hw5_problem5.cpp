#include<iostream>
using namespace std;
int main()
{
	//problem5
	int 
}